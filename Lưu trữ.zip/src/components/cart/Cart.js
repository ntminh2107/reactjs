import React from "react";

const Cart = () => {
  return <></>;
};
export default Cart;
